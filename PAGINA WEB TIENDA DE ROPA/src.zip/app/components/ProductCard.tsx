import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  badge?: string;
}

interface ProductCardProps {
  product: Product;
  index: number;
  onAddToCart: (product: Product, size: string) => void;
}

const sizes = ['XS', 'S', 'M', 'L', 'XL'];

export function ProductCard({ product, index, onAddToCart }: ProductCardProps) {
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [showSizeError, setShowSizeError] = useState(false);

  const handleAddToCart = () => {
    if (!selectedSize) {
      setShowSizeError(true);
      setTimeout(() => setShowSizeError(false), 2000);
      return;
    }
    onAddToCart(product, selectedSize);
    setSelectedSize(null);
  };

  return (
    <motion.div
      className="group relative"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden mb-6 bg-white/5">
        <motion.div
          animate={{ scale: isHovered ? 1.05 : 1 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="w-full h-full"
        >
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </motion.div>

        {/* Badge */}
        {product.badge && (
          <motion.div
            className="absolute top-4 left-4 bg-white text-black px-4 py-2 text-xs font-bold tracking-wider"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 + 0.3 }}
          >
            {product.badge}
          </motion.div>
        )}

        {/* Hover Overlay */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              className="absolute inset-0 bg-black/40 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="text-white text-sm tracking-widest"
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -10, opacity: 0 }}
                transition={{ delay: 0.1 }}
              >
                VER DETALLES
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Product Info */}
      <div className="space-y-4">
        <div className="flex items-start justify-between">
          <h3 className="text-2xl font-bold tracking-tight">{product.name}</h3>
          <div className="text-xl font-bold">€{product.price}</div>
        </div>

        {/* Size Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-sm text-white/60">Selecciona tu talla</div>
            <AnimatePresence>
              {showSizeError && (
                <motion.div
                  className="text-xs text-red-400"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0 }}
                >
                  Selecciona una talla
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <div className="flex gap-2">
            {sizes.map((size) => (
              <motion.button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`flex-1 py-3 text-sm font-bold tracking-wide border transition-colors ${
                  selectedSize === size
                    ? 'bg-white text-black border-white'
                    : 'border-white/20 hover:border-white/40'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {size}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Add to Cart Button */}
        <motion.button
          onClick={handleAddToCart}
          className="w-full bg-white/10 hover:bg-white hover:text-black border border-white/20 hover:border-white py-4 font-bold tracking-wide transition-colors"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          AÑADIR AL CARRITO
        </motion.button>

        {/* Stock Indicator */}
        <div className="flex items-center gap-2 text-xs text-white/40">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span>Solo quedan pocas unidades</span>
        </div>
      </div>
    </motion.div>
  );
}
